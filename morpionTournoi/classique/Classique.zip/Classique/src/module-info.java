/**
 * 
 */
/**
 * @author Documents
 *
 */
module Classique {
}