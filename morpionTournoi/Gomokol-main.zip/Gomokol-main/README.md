# Gomokol

Implementation of a protocol for the Gomoku game.
