#ifndef PARSER_H
#define PARSER_H

#include <stdlib.h>
#include <stdbool.h>

#include "client.h"


bool parse(t_server server, int order);

#endif